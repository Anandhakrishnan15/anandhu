<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="#">

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/f9f66e2928.js" crossorigin="anonymous"></script>

    <title>whatsapp master class</title>
</head>

<script>
    function openNav() {
        document.getElementById("myNav").style.width = "100%";
    }

    function closeNav() {
        document.getElementById("myNav").style.width = "0%";
    }
</script>

<body>
    <section id="box1">
        <div class="box1_container">
            <div class="box1-holder">
                <div class="box1_heading">
                    <p>
                        <span style="font-size: 60px;">Want to get
                            <strong>Hike</strong> and <strong>Promotion</strong>
                            in your <strong>Dream Career</strong>?</span>
                    </p>
                </div>
                <div class="box1_img">
                    <img srcset="https://s3.us-east-1.amazonaws.com/contents.newzenler.com/7686/library/career-progress-concept-illustration-114360-24915f8704990999f_sm.jpg 480w, https://s3.us-east-1.amazonaws.com/contents.newzenler.com/7686/library/career-progress-concept-illustration-114360-24915f8704990999f_md.jpg 640w, https://s3.us-east-1.amazonaws.com/contents.newzenler.com/7686/library/career-progress-concept-illustration-114360-24915f8704990999f_lg.jpg 1280w" class="" style="width: 100%;">

                </div>
            </div>
            <!------------------------button------------------------------------------------>

            <div class="button-container">
                <div class="button_holder">
                    <span style="font-size:28px; cursor:pointer;" onclick="openNav()">
                        <button>
                            BOOK YOUR SET NOW
                        </button></span>
                </div>
            </div>
            <!------------------------------------------------------------------------>

        </div>
        <!------------------------off-cannvas------------------------------------------------>
        <div id="myNav" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="overlay-content">
                <a href="#">About</a>
                <a href="#">Services</a>
                <a href="#">Clients</a>
                <a href="#">Contact</a>
            </div>
        </div>

        <!----------------------------------------------------------------------------------------------->

        <div class="heading2_box">
            <div class="box-text">
                <p>
                    <span style="color: rgb(255, 255, 255);">
                        <span style="font-size: 38px;">Think that you can’t be ahead of the competition&nbsp;</span>
                    </span>

                    <br>
                    <span style="color: rgb(255, 255, 255);">
                        <span style="font-size: 38px;">without big <strong>experience</strong> or <strong>skill</strong>?<br>
                            &nbsp;Feel that you have made
                            <strong>mistakes</strong>,&nbsp;</span>
                    </span>
                    <span style="color: rgb(255, 255, 255);">
                        <span style="font-size: 38px;">don’t fit in &nbsp;</span>
                    </span><br><span style="color: rgb(255, 255, 255);">
                        <span style="font-size: 38px;">and prefer</span></span>
                    <span style="color: rgb(255, 255, 255);">
                        <span style="font-size: 38px;">work-life balance?</span>
                    </span>
                </p>
            </div>

            <div class="box-text2">
                <p>
                    <span style="font-size: 28px;">Well then you need to explore <br>
                        we <strong>Coach</strong> and <strong>Train</strong>
                        <br>
                        <strong>GO-GETTERS</strong> to prepare for their
                        <strong>Hike</strong> and <strong>Promotion</strong>
                        in their <strong>Dream Career</strong> using
                        <br>
                        <span style="color: rgb(184, 49, 47);"><strong>“5-day Masterclass to Position Yourself to WIN”</strong>
                        </span><br>at amazing
                        <span style="color: rgb(184, 49, 47);">introductory</span>
                        offer price at discount.</span>
                </p>
            </div>
            <!------------------------button------------------------------------------------>

            <div class="button-container">
                <div class="button_holder">
                    <span style="font-size:28px; cursor:pointer;" onclick="openNav()">
                        <button>
                            BOOK YOUR SET NOW
                        </button></span>
                </div>
            </div>
<!------------------------------------------------------------------------------->
        </div>

        <div class="mentor-partcontainer">
            <div class="mentr_box_hoolder">
                <div class="mentor-img">
                    <img src="https://s3.us-east-1.amazonaws.com/contents.newzenler.com/7686/library/0015f7eaabad65b5_lg.jpg" class="" style="width:100%">
                </div>
                <div class="mentor_details">
                <p><span style="font-size: 30px;">
                Hi I am Nitin, for the last 25 years I have lived by one word “Challenge”.
                <br>I started career as a Technologist, grew to be a People Manager on to corporate leader.<br>
                <br>In 2015 I started my journey on Leadership Coach and founded an organisation called <strong>iPause</strong>.<br>
                <br>My motto is to Love, Learn and Serve: <strong>Unconditionally</strong> as I embark on a new challenge to help 100 thousand people to be best at what they do.<br>
                <br>After &nbsp; helping many colleagues and clients in my long career to become more &nbsp; successful in their dream career, I have found that all one needs to &nbsp;get &nbsp;ahead is to 5 step process from <strong>discovering self</strong> to <strong>Positioning to Win</strong>.<br>
                <br>Want to know what these Steps are and how to propel your journey to make it faster?<br>&nbsp;Me and my team have developed a<br>
            </span>
            <span style="color: rgb(184, 49, 47);">
            <span style="font-size: 40px;"><strong>5-day Masterclass</strong></span></span>
            <span style="font-size: 30px;">
            <br>that will enable you by 5th day to develop a Blueprint of Step by Step process to achieve your Dream Career Goal.</span></p>
                </div>
            </div>
              <!------------------------button------------------------------------------------>

              <div class="button-container">
                <div class="button_holder">
                    <span style="font-size:28px; cursor:pointer;" onclick="openNav()">
                        <button>
                            BOOK YOUR SET NOW
                        </button></span>
                </div>
            </div>
<!------------------------------------------------------------------------------->
        </div>

        <div class="banner_box-container">
            <div class="banner_holder">
            <span style="font-size: 36px; color:white;"><strong>Sounds Cool?</strong></span><br>

            <span style="font-size: 30px; color:gold;">&nbsp;Here’s what you will achieve each day of the WhatsApp training with us:</span>
            </div>

        </div>

        <div class="workshopday_box-conatiner">
            <div class="workshopday_box-holder">
                
            </div>

        </div>
    </section>

</body>

</html>